import { Flame, Trophy, Star, Lock, CheckCircle2, Circle, ChevronRight, TrendingUp, BookOpen } from "lucide-react";
import type { Screen } from "../App";

interface Props {
  onNavigate: (s: Screen) => void;
}

const skillNodes = [
  { id: 1, label: "Nhập môn OOP", status: "done", x: 50, y: 10 },
  { id: 2, label: "Kế thừa", status: "done", x: 30, y: 28 },
  { id: 3, label: "Đa hình", status: "active", x: 65, y: 28 },
  { id: 4, label: "Abstraction", status: "locked", x: 15, y: 48 },
  { id: 5, label: "Interface", status: "locked", x: 45, y: 48 },
  { id: 6, label: "Design Pattern", status: "locked", x: 75, y: 48 },
  { id: 7, label: "SOLID", status: "locked", x: 50, y: 68 },
];

const edges = [
  [1, 2], [1, 3], [2, 4], [2, 5], [3, 5], [3, 6], [5, 7], [6, 7],
];

const nodeColor = (status: string) =>
  status === "done" ? "#10B981" : status === "active" ? "#6366F1" : "#1E2A42";

const nodeTextColor = (status: string) =>
  status === "done" ? "#fff" : status === "active" ? "#fff" : "#475569";

export default function StudentDashboard({ onNavigate }: Props) {
  return (
    <div className="p-6 min-h-full" style={{ background: "#07090F" }}>
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-lg font-semibold" style={{ color: "#E2E8F0" }}>Dashboard học tập</h1>
          <p className="text-sm" style={{ color: "#475569" }}>Lập trình hướng đối tượng — Nhóm 01</p>
        </div>
        <div className="flex items-center gap-3">
          {/* Streak */}
          <div
            className="flex items-center gap-2 px-3 py-1.5 rounded-lg border"
            style={{ background: "rgba(245,158,11,0.08)", borderColor: "rgba(245,158,11,0.25)" }}
          >
            <Flame size={15} style={{ color: "#F59E0B" }} />
            <span className="text-sm font-bold" style={{ color: "#F59E0B" }}>14</span>
            <span className="text-xs" style={{ color: "#78350F" }}>ngày streak</span>
          </div>
          {/* League */}
          <div
            className="flex items-center gap-2 px-3 py-1.5 rounded-lg border"
            style={{ background: "rgba(99,102,241,0.08)", borderColor: "rgba(99,102,241,0.25)" }}
          >
            <Trophy size={14} style={{ color: "#818CF8" }} />
            <span className="text-xs font-medium" style={{ color: "#818CF8" }}>Hạng Bạc</span>
          </div>
          {/* XP */}
          <div
            className="flex items-center gap-2 px-3 py-1.5 rounded-lg border"
            style={{ background: "rgba(34,211,238,0.08)", borderColor: "rgba(34,211,238,0.2)" }}
          >
            <Star size={14} style={{ color: "#22D3EE" }} />
            <span className="text-sm font-bold" style={{ color: "#22D3EE" }}>3,240</span>
            <span className="text-xs" style={{ color: "#164E63" }}>XP</span>
          </div>
        </div>
      </div>

      <div className="grid gap-5" style={{ gridTemplateColumns: "1fr 320px" }}>
        {/* Skill Tree */}
        <div className="rounded-xl border p-5" style={{ background: "#0D1120", borderColor: "#1E2A42" }}>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-semibold" style={{ color: "#E2E8F0" }}>Cây kỹ năng — OOP</h2>
            <span className="text-xs px-2 py-0.5 rounded" style={{ background: "rgba(16,185,129,0.12)", color: "#10B981" }}>
              2/7 hoàn thành
            </span>
          </div>

          {/* SVG Skill Tree */}
          <div className="relative" style={{ height: 360 }}>
            <svg className="absolute inset-0 w-full h-full" style={{ zIndex: 0 }}>
              {edges.map(([from, to], i) => {
                const f = skillNodes.find((n) => n.id === from)!;
                const t = skillNodes.find((n) => n.id === to)!;
                return (
                  <line
                    key={i}
                    x1={`${f.x}%`} y1={`${f.y + 4}%`}
                    x2={`${t.x}%`} y2={`${t.y - 4}%`}
                    stroke={f.status === "done" && t.status !== "locked" ? "#10B981" : "#1E2A42"}
                    strokeWidth={1.5}
                    strokeDasharray={t.status === "locked" ? "4,4" : "none"}
                    opacity={0.6}
                  />
                );
              })}
            </svg>
            {skillNodes.map((node) => (
              <div
                key={node.id}
                onClick={() => node.status !== "locked" && onNavigate("workspace")}
                className="absolute flex flex-col items-center"
                style={{
                  left: `${node.x}%`, top: `${node.y}%`,
                  transform: "translate(-50%, -50%)",
                  cursor: node.status === "locked" ? "default" : "pointer",
                  zIndex: 1,
                }}
              >
                <div
                  className="rounded-full flex items-center justify-center transition-transform"
                  style={{
                    width: 44, height: 44,
                    background: nodeColor(node.status),
                    border: node.status === "active" ? "2px solid #818CF8" : "2px solid transparent",
                    boxShadow: node.status === "active" ? "0 0 12px rgba(99,102,241,0.4)" : "none",
                  }}
                  onMouseEnter={(e) => node.status !== "locked" && ((e.currentTarget as HTMLElement).style.transform = "scale(1.1)")}
                  onMouseLeave={(e) => ((e.currentTarget as HTMLElement).style.transform = "scale(1)")}
                >
                  {node.status === "done" ? <CheckCircle2 size={18} color="#fff" /> :
                    node.status === "active" ? <Circle size={18} color="#fff" /> :
                      <Lock size={14} color="#475569" />}
                </div>
                <span
                  className="mt-1.5 text-center leading-tight"
                  style={{ fontSize: 10, color: nodeTextColor(node.status), maxWidth: 72, textAlign: "center" }}
                >
                  {node.label}
                </span>
              </div>
            ))}
          </div>

          <button
            onClick={() => onNavigate("workspace")}
            className="mt-2 w-full flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm font-medium transition-all"
            style={{ background: "#6366F1", color: "#fff" }}
            onMouseEnter={(e) => ((e.currentTarget as HTMLElement).style.background = "#5557e8")}
            onMouseLeave={(e) => ((e.currentTarget as HTMLElement).style.background = "#6366F1")}
          >
            <BookOpen size={15} />
            Tiếp tục học: Đa hình
            <ChevronRight size={15} />
          </button>
        </div>

        {/* Right panel */}
        <div className="flex flex-col gap-4">
          {/* Weekly XP chart */}
          <div className="rounded-xl border p-4" style={{ background: "#0D1120", borderColor: "#1E2A42" }}>
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm font-medium" style={{ color: "#E2E8F0" }}>XP tuần này</span>
              <TrendingUp size={14} style={{ color: "#22D3EE" }} />
            </div>
            <div className="flex items-end gap-1.5" style={{ height: 60 }}>
              {[40, 65, 30, 80, 95, 50, 100].map((h, i) => (
                <div key={i} className="flex-1 flex flex-col items-center gap-1">
                  <div
                    className="w-full rounded-sm transition-all"
                    style={{
                      height: `${h * 0.6}%`,
                      minHeight: 4,
                      background: i === 6 ? "#6366F1" : "#1E2A42",
                    }}
                  />
                  <span className="text-xs" style={{ color: "#334155", fontSize: 9 }}>
                    {["T2", "T3", "T4", "T5", "T6", "T7", "CN"][i]}
                  </span>
                </div>
              ))}
            </div>
            <div className="mt-2 text-xs" style={{ color: "#475569" }}>+480 XP hôm nay</div>
          </div>

          {/* League */}
          <div className="rounded-xl border p-4" style={{ background: "#0D1120", borderColor: "#1E2A42" }}>
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm font-medium" style={{ color: "#E2E8F0" }}>Bảng xếp hạng Bạc</span>
              <span className="text-xs" style={{ color: "#475569" }}>Tuần 28</span>
            </div>
            {[
              { name: "Trần Thị B", xp: 1240, rank: 1, me: false },
              { name: "Lê Văn C", xp: 980, rank: 2, me: false },
              { name: "Nguyễn Văn A", xp: 840, rank: 3, me: true },
              { name: "Phạm Thị D", xp: 720, rank: 4, me: false },
              { name: "Hoàng Văn E", xp: 610, rank: 5, me: false },
            ].map((p) => (
              <div
                key={p.rank}
                className="flex items-center gap-2 py-1.5 px-2 rounded-md mb-0.5"
                style={{ background: p.me ? "rgba(99,102,241,0.12)" : "transparent" }}
              >
                <span className="text-xs font-mono w-4" style={{ color: p.rank <= 3 ? "#F59E0B" : "#334155" }}>
                  {p.rank}
                </span>
                <span className="flex-1 text-xs truncate" style={{ color: p.me ? "#818CF8" : "#64748B" }}>
                  {p.name}
                </span>
                <span className="text-xs font-mono" style={{ color: "#475569" }}>{p.xp} XP</span>
              </div>
            ))}
            <div className="mt-2 text-xs text-center" style={{ color: "#334155" }}>
              Còn 400 XP để thăng hạng Vàng ↑
            </div>
          </div>

          {/* Upcoming */}
          <div className="rounded-xl border p-4" style={{ background: "#0D1120", borderColor: "#1E2A42" }}>
            <span className="text-sm font-medium block mb-3" style={{ color: "#E2E8F0" }}>Nhiệm vụ hôm nay</span>
            {[
              { label: "Hoàn thành Quiz: Đa hình", xp: "+50 XP", done: true },
              { label: "Xem Tech Reel mới", xp: "+10 XP", done: false },
              { label: "Vẽ Mindmap Chương 1", xp: "+200 XP", done: false },
            ].map((t, i) => (
              <div key={i} className="flex items-center gap-2 py-1.5">
                <div
                  className="rounded-full shrink-0"
                  style={{ width: 6, height: 6, background: t.done ? "#10B981" : "#1E2A42" }}
                />
                <span className="flex-1 text-xs" style={{ color: t.done ? "#475569" : "#94A3B8", textDecoration: t.done ? "line-through" : "none" }}>
                  {t.label}
                </span>
                <span className="text-xs font-mono" style={{ color: "#22D3EE", fontSize: 10 }}>{t.xp}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
