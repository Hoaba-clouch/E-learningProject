import { useState } from "react";
import {
  FileText, Video, HelpCircle, GitBranch, Code2,
  MessageSquare, Send, Sparkles, ChevronRight, CheckCircle2, Lock, Play
} from "lucide-react";

type Tab = "lecture" | "video" | "quiz" | "mindmap" | "code";

const tabs: { id: Tab; icon: React.ReactNode; label: string }[] = [
  { id: "lecture", icon: <FileText size={13} />, label: "Bài đọc" },
  { id: "video", icon: <Video size={13} />, label: "Video AI" },
  { id: "quiz", icon: <HelpCircle size={13} />, label: "Quiz" },
  { id: "mindmap", icon: <GitBranch size={13} />, label: "Mindmap" },
  { id: "code", icon: <Code2 size={13} />, label: "Code" },
];

const quizOptions = [
  { id: "a", text: "Lớp con nhận đặc điểm từ lớp cha" },
  { id: "b", text: "Lớp cha nhận đặc điểm từ lớp con" },
  { id: "c", text: "Hai lớp chia sẻ dữ liệu ngang hàng" },
  { id: "d", text: "Không có quan hệ nào giữa hai lớp" },
];

const chatHistory = [
  { from: "mino", text: "Chào bạn! Tôi là Mino 🤖 — hãy bắt đầu vẽ sơ đồ tư duy nhé. Thử kéo một Node mới từ thanh công cụ bên trái!" },
  { from: "user", text: "Mình chưa hiểu lắm về quan hệ extends giữa Animal và Dog" },
  { from: "mino", text: "Câu hỏi hay! Hãy nghĩ thử: Con chó (Dog) có phải là một loại động vật (Animal) không? Nếu CÓ, thì lớp nào là lớp **chuyên biệt hơn** — lớp nào kế thừa đặc điểm từ lớp nào?" },
];

export default function LearningWorkspace() {
  const [tab, setTab] = useState<Tab>("lecture");
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [submitted, setSubmitted] = useState(false);
  const [msg, setMsg] = useState("");
  const [messages, setMessages] = useState(chatHistory);

  const sendMessage = () => {
    if (!msg.trim()) return;
    setMessages((m) => [...m, { from: "user", text: msg }]);
    setMsg("");
    setTimeout(() => {
      setMessages((m) => [...m, { from: "mino", text: "Rất tốt! Bạn đang đi đúng hướng. Thử vẽ mũi tên từ Dog → Animal với nhãn 'extends'. Nếu Dog là lớp con, mũi tên sẽ đi từ đâu đến đâu?" }]);
    }, 1200);
  };

  return (
    <div className="flex h-full" style={{ background: "#07090F" }}>
      {/* Left: Lesson outline */}
      <aside className="shrink-0 border-r flex flex-col" style={{ width: 220, background: "#0D1120", borderColor: "#1E2A42" }}>
        <div className="px-4 py-4 border-b" style={{ borderColor: "#1E2A42" }}>
          <div className="text-xs uppercase tracking-wider mb-1" style={{ color: "#475569" }}>Chương 1</div>
          <div className="text-sm font-semibold" style={{ color: "#E2E8F0" }}>Kế thừa — Inheritance</div>
        </div>
        <div className="flex-1 overflow-y-auto py-3 px-2 flex flex-col gap-0.5">
          {[
            { label: "1.1 Khái niệm Kế thừa", status: "done" },
            { label: "1.2 extends và super", status: "active" },
            { label: "1.3 Override methods", status: "locked" },
            { label: "🧠 Mindmap tổng hợp", status: "optional" },
            { label: "💻 Bài tập GitHub", status: "locked" },
          ].map((l, i) => (
            <button
              key={i}
              className="flex items-center gap-2 px-2 py-2 rounded text-left w-full"
              style={{
                background: l.status === "active" ? "rgba(99,102,241,0.12)" : "transparent",
                opacity: l.status === "locked" ? 0.5 : 1,
                cursor: l.status === "locked" ? "default" : "pointer",
              }}
            >
              {l.status === "done" ? <CheckCircle2 size={12} style={{ color: "#10B981", shrink: 0 }} /> :
                l.status === "active" ? <Play size={12} style={{ color: "#6366F1" }} /> :
                  l.status === "optional" ? <Sparkles size={12} style={{ color: "#F59E0B" }} /> :
                    <Lock size={12} style={{ color: "#334155" }} />}
              <span className="text-xs leading-tight" style={{ color: l.status === "active" ? "#818CF8" : l.status === "done" ? "#475569" : "#64748B" }}>
                {l.label}
              </span>
            </button>
          ))}
        </div>
        <div className="px-3 pb-3">
          <div className="rounded-lg p-2" style={{ background: "#07090F" }}>
            <div className="text-xs mb-1" style={{ color: "#475569" }}>Tiến độ chương</div>
            <div className="rounded-full overflow-hidden" style={{ height: 4, background: "#1E2A42" }}>
              <div className="h-full rounded-full" style={{ width: "40%", background: "#6366F1" }} />
            </div>
            <div className="text-xs mt-1" style={{ color: "#475569" }}>2/5 bài hoàn thành</div>
          </div>
        </div>
      </aside>

      {/* Center: Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Tab bar */}
        <div className="flex items-center gap-1 px-4 pt-4 pb-0 border-b" style={{ borderColor: "#1E2A42" }}>
          {tabs.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className="flex items-center gap-1.5 px-3 py-2 rounded-t text-xs font-medium transition-all border-b-2"
              style={{
                borderColor: tab === t.id ? "#6366F1" : "transparent",
                color: tab === t.id ? "#818CF8" : "#475569",
                background: "transparent",
                marginBottom: -1,
              }}
            >
              {t.icon}
              {t.label}
            </button>
          ))}
        </div>

        <div className="flex-1 overflow-y-auto p-6">
          {tab === "lecture" && (
            <div className="max-w-2xl">
              <div className="text-xs uppercase tracking-wider mb-1" style={{ color: "#6366F1" }}>Bài đọc · AI tóm tắt</div>
              <h2 className="text-lg font-semibold mb-4" style={{ color: "#E2E8F0" }}>1.2 Từ khóa extends và super trong Java</h2>
              <div className="prose text-sm leading-relaxed" style={{ color: "#94A3B8" }}>
                <p className="mb-4">Trong Java, từ khóa <code style={{ background: "#1E2A42", padding: "2px 6px", borderRadius: 4, color: "#22D3EE", fontFamily: "monospace" }}>extends</code> được dùng để tạo quan hệ <strong style={{ color: "#E2E8F0" }}>kế thừa</strong> giữa hai lớp. Lớp con (subclass) nhận toàn bộ thuộc tính và phương thức từ lớp cha (superclass).</p>
                <div className="rounded-lg p-4 mb-4 border font-mono text-sm" style={{ background: "#080B14", borderColor: "#1E2A42", color: "#22D3EE" }}>
                  <div style={{ color: "#475569" }}>// Lớp cha</div>
                  <div><span style={{ color: "#818CF8" }}>class</span> <span style={{ color: "#F59E0B" }}>Animal</span> {"{"}</div>
                  <div className="ml-4"><span style={{ color: "#818CF8" }}>String</span> name;</div>
                  <div className="ml-4"><span style={{ color: "#818CF8" }}>void</span> <span style={{ color: "#22D3EE" }}>speak</span>() {"{ }"}</div>
                  <div>{"}"}</div>
                  <div className="mt-2" style={{ color: "#475569" }}>// Lớp con kế thừa Animal</div>
                  <div><span style={{ color: "#818CF8" }}>class</span> <span style={{ color: "#F59E0B" }}>Dog</span> <span style={{ color: "#818CF8" }}>extends</span> <span style={{ color: "#F59E0B" }}>Animal</span> {"{"}</div>
                  <div className="ml-4"><span style={{ color: "#818CF8" }}>void</span> <span style={{ color: "#22D3EE" }}>speak</span>() {"{"}</div>
                  <div className="ml-8"><span style={{ color: "#22D3EE" }}>super</span>.<span style={{ color: "#22D3EE" }}>speak</span>(); <span style={{ color: "#475569" }}>// Gọi phương thức lớp cha</span></div>
                  <div className="ml-8">System.out.<span style={{ color: "#22D3EE" }}>println</span>(<span style={{ color: "#10B981" }}>"Woof!"</span>);</div>
                  <div className="ml-4">{"}"}</div>
                  <div>{"}"}</div>
                </div>
                <p className="mb-3">Từ khóa <code style={{ background: "#1E2A42", padding: "2px 6px", borderRadius: 4, color: "#22D3EE", fontFamily: "monospace" }}>super</code> dùng để truy cập thuộc tính và phương thức của <strong style={{ color: "#E2E8F0" }}>lớp cha</strong> trực tiếp từ bên trong lớp con.</p>
              </div>
            </div>
          )}

          {tab === "video" && (
            <div className="max-w-2xl">
              <div className="text-xs uppercase tracking-wider mb-3" style={{ color: "#6366F1" }}>Video · AI Generated</div>
              <div
                className="rounded-xl flex items-center justify-center cursor-pointer border relative overflow-hidden"
                style={{ aspectRatio: "16/9", background: "#0D1120", borderColor: "#1E2A42" }}
              >
                <div className="absolute inset-0 opacity-10" style={{ background: "linear-gradient(135deg,#6366F1,#22D3EE)" }} />
                <div className="flex flex-col items-center gap-3">
                  <div className="rounded-full flex items-center justify-center" style={{ width: 56, height: 56, background: "rgba(99,102,241,0.9)" }}>
                    <Play size={22} color="#fff" fill="#fff" />
                  </div>
                  <span className="text-sm" style={{ color: "#94A3B8" }}>Video AI · 4:32 phút</span>
                </div>
                <div className="absolute bottom-3 right-3 px-2 py-1 rounded text-xs" style={{ background: "rgba(99,102,241,0.8)", color: "#fff" }}>
                  AI Generated
                </div>
              </div>
              <div className="mt-3 text-sm" style={{ color: "#64748B" }}>extends và super trong Java — Video bài giảng được tạo tự động từ tài liệu PDF</div>
            </div>
          )}

          {tab === "quiz" && (
            <div className="max-w-xl">
              <div className="text-xs uppercase tracking-wider mb-1" style={{ color: "#6366F1" }}>Lesson Quiz · Bắt buộc ≥ 70%</div>
              <h3 className="text-base font-semibold mb-6" style={{ color: "#E2E8F0" }}>
                Câu 1/3: Kế thừa trong OOP là gì?
              </h3>
              <div className="flex flex-col gap-2">
                {quizOptions.map((opt) => (
                  <button
                    key={opt.id}
                    onClick={() => !submitted && setSelectedOption(opt.id)}
                    className="flex items-center gap-3 px-4 py-3 rounded-lg border text-left transition-all"
                    style={{
                      background: selectedOption === opt.id ? "rgba(99,102,241,0.15)" : "transparent",
                      borderColor: submitted && opt.id === "a" ? "#10B981" : selectedOption === opt.id ? "#6366F1" : "#1E2A42",
                      color: selectedOption === opt.id ? "#E2E8F0" : "#94A3B8",
                    }}
                  >
                    <span
                      className="rounded flex items-center justify-center text-xs font-mono shrink-0"
                      style={{ width: 24, height: 24, background: selectedOption === opt.id ? "#6366F1" : "#1E2A42", color: selectedOption === opt.id ? "#fff" : "#475569" }}
                    >
                      {opt.id.toUpperCase()}
                    </span>
                    <span className="text-sm">{opt.text}</span>
                    {submitted && opt.id === "a" && <CheckCircle2 size={16} className="ml-auto" style={{ color: "#10B981" }} />}
                  </button>
                ))}
              </div>
              {!submitted ? (
                <button
                  onClick={() => selectedOption && setSubmitted(true)}
                  disabled={!selectedOption}
                  className="mt-5 flex items-center gap-2 px-5 py-2.5 rounded-lg text-sm font-medium transition-all"
                  style={{ background: selectedOption ? "#6366F1" : "#1E2A42", color: selectedOption ? "#fff" : "#475569", cursor: selectedOption ? "pointer" : "default" }}
                >
                  Xác nhận <ChevronRight size={15} />
                </button>
              ) : (
                <div className="mt-4 p-3 rounded-lg border" style={{ background: "rgba(16,185,129,0.08)", borderColor: "rgba(16,185,129,0.3)" }}>
                  <span className="text-sm font-medium" style={{ color: "#10B981" }}>✓ Chính xác! +15 XP</span>
                  <p className="text-xs mt-1" style={{ color: "#475569" }}>Kế thừa (Inheritance) là cơ chế lớp con nhận thuộc tính và hành vi từ lớp cha.</p>
                </div>
              )}
            </div>
          )}

          {tab === "mindmap" && (
            <div className="flex flex-col items-center justify-center" style={{ minHeight: 300 }}>
              <div className="text-center max-w-sm">
                <GitBranch size={36} className="mx-auto mb-3" style={{ color: "#6366F1" }} />
                <h3 className="text-base font-semibold mb-2" style={{ color: "#E2E8F0" }}>Mindmap Canvas</h3>
                <p className="text-sm mb-4" style={{ color: "#64748B" }}>Vẽ sơ đồ tư duy hệ thống hóa kiến thức Chương 1. Hoàn thành để nhận +200 XP.</p>
                <div className="flex gap-2 justify-center mb-4">
                  {["Điền vào chỗ trống", "Hoàn thiện sơ đồ", "Vẽ tự do"].map((m, i) => (
                    <button key={i} className="px-3 py-1.5 rounded border text-xs transition-all"
                      style={{ background: i === 2 ? "rgba(99,102,241,0.15)" : "transparent", borderColor: i === 2 ? "#6366F1" : "#1E2A42", color: i === 2 ? "#818CF8" : "#64748B" }}>
                      Cấp {i + 1}
                    </button>
                  ))}
                </div>
                <div className="rounded-xl border flex items-center justify-center" style={{ height: 220, background: "#0D1120", borderColor: "#1E2A42" }}>
                  <span className="text-xs" style={{ color: "#334155" }}>Canvas React Flow sẽ render tại đây</span>
                </div>
              </div>
            </div>
          )}

          {tab === "code" && (
            <div className="max-w-2xl">
              <div className="text-xs uppercase tracking-wider mb-3" style={{ color: "#6366F1" }}>Online Compiler</div>
              <div className="rounded-xl border overflow-hidden" style={{ borderColor: "#1E2A42" }}>
                <div className="flex items-center justify-between px-4 py-2" style={{ background: "#080B14", borderBottom: "1px solid #1E2A42" }}>
                  <span className="text-xs font-mono" style={{ color: "#475569" }}>Main.java</span>
                  <button className="px-3 py-1 rounded text-xs font-medium" style={{ background: "#10B981", color: "#fff" }}>▶ Chạy</button>
                </div>
                <textarea
                  rows={12}
                  defaultValue={`class Animal {
    String name;
    void speak() {
        System.out.println("...");
    }
}

class Dog extends Animal {
    // TODO: Override phương thức speak()
    // Gợi ý: Dùng super.speak() trước

}`}
                  className="w-full p-4 font-mono text-sm outline-none resize-none"
                  style={{ background: "#080B14", color: "#22D3EE", fontSize: 13 }}
                />
                <div className="px-4 py-3 font-mono text-xs" style={{ background: "#040609", borderTop: "1px solid #1E2A42", color: "#10B981" }}>
                  {">"} Sẵn sàng chạy...
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Right: AI Mentor Mino */}
      <aside className="shrink-0 border-l flex flex-col" style={{ width: 260, background: "#0D1120", borderColor: "#1E2A42" }}>
        <div className="px-4 py-3 border-b flex items-center gap-2" style={{ borderColor: "#1E2A42" }}>
          <div
            className="rounded-full flex items-center justify-center"
            style={{ width: 28, height: 28, background: "linear-gradient(135deg,#6366F1,#22D3EE)" }}
          >
            <Sparkles size={13} color="#fff" />
          </div>
          <div>
            <div className="text-xs font-semibold" style={{ color: "#E2E8F0" }}>Mino</div>
            <div className="text-xs" style={{ color: "#22D3EE", fontSize: 10 }}>AI Mentor · Socratic Mode</div>
          </div>
          <div className="ml-auto w-2 h-2 rounded-full" style={{ background: "#10B981" }} />
        </div>

        <div className="flex-1 overflow-y-auto px-3 py-3 flex flex-col gap-2">
          {messages.map((m, i) => (
            <div
              key={i}
              className={`flex ${m.from === "user" ? "justify-end" : "justify-start"}`}
            >
              <div
                className="rounded-xl px-3 py-2 text-xs leading-relaxed max-w-[90%]"
                style={{
                  background: m.from === "user" ? "rgba(99,102,241,0.2)" : "#0F1629",
                  color: m.from === "user" ? "#C7D2FE" : "#94A3B8",
                  borderRadius: m.from === "user" ? "12px 12px 4px 12px" : "4px 12px 12px 12px",
                }}
              >
                {m.text}
              </div>
            </div>
          ))}
        </div>

        <div className="px-3 pb-3">
          <div className="flex items-center gap-2 rounded-lg border px-2 py-1.5" style={{ background: "#07090F", borderColor: "#1E2A42" }}>
            <input
              value={msg}
              onChange={(e) => setMsg(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && sendMessage()}
              placeholder="Hỏi Mino..."
              className="flex-1 bg-transparent text-xs outline-none"
              style={{ color: "#E2E8F0" }}
            />
            <button onClick={sendMessage} style={{ color: "#6366F1" }}>
              <Send size={14} />
            </button>
          </div>
          <div className="mt-1.5 flex gap-1.5">
            {["Giải thích lại", "Gợi ý", "Ví dụ"].map((q) => (
              <button
                key={q}
                onClick={() => { setMsg(q); }}
                className="flex-1 py-1 rounded text-xs border transition-colors"
                style={{ background: "transparent", borderColor: "#1E2A42", color: "#475569", fontSize: 10 }}
              >
                {q}
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center gap-2 mx-3 mb-3 px-3 py-2 rounded-lg" style={{ background: "rgba(245,158,11,0.08)", border: "1px solid rgba(245,158,11,0.15)" }}>
          <MessageSquare size={12} style={{ color: "#F59E0B" }} />
          <span className="text-xs" style={{ color: "#92400E", fontSize: 10 }}>Mino không trả lời trực tiếp — chỉ gợi mở tư duy</span>
        </div>
      </aside>
    </div>
  );
}
