import { useState } from "react";
import { GitFork, Mail, Zap, ArrowRight } from "lucide-react";
import type { Role } from "../App";

interface Props {
  onLogin: (role: Role) => void;
}

export default function LoginScreen({ onLogin }: Props) {
  const [selected, setSelected] = useState<Role>("student");

  return (
    <div
      className="min-h-screen flex items-center justify-center relative overflow-hidden"
      style={{ background: "#07090F" }}
    >
      {/* Grid bg */}
      <div
        className="absolute inset-0 opacity-20"
        style={{
          backgroundImage: `linear-gradient(#1E2A42 1px, transparent 1px), linear-gradient(90deg, #1E2A42 1px, transparent 1px)`,
          backgroundSize: "48px 48px",
        }}
      />
      {/* Glow */}
      <div
        className="absolute rounded-full opacity-20 blur-3xl"
        style={{ width: 600, height: 600, background: "#6366F1", top: "50%", left: "50%", transform: "translate(-50%,-50%)" }}
      />

      <div className="relative z-10 w-full max-w-md px-6">
        {/* Logo */}
        <div className="flex items-center gap-3 mb-10">
          <div
            className="flex items-center justify-center rounded-lg"
            style={{ width: 40, height: 40, background: "#6366F1" }}
          >
            <Zap size={20} color="#fff" fill="#fff" />
          </div>
          <div>
            <div className="text-xl font-bold tracking-wide" style={{ color: "#E2E8F0", fontFamily: "monospace" }}>
              CODE<span style={{ color: "#6366F1" }}>·</span>MIND
            </div>
            <div className="text-xs" style={{ color: "#475569" }}>AI Learning Platform</div>
          </div>
        </div>

        <div className="rounded-xl border p-8" style={{ background: "#0D1120", borderColor: "#1E2A42" }}>
          <h1 className="text-xl font-semibold mb-1" style={{ color: "#E2E8F0" }}>Đăng nhập</h1>
          <p className="text-sm mb-6" style={{ color: "#64748B" }}>Chào mừng trở lại nền tảng học lập trình AI</p>

          {/* Role selector */}
          <div className="mb-5">
            <div className="text-xs font-medium mb-2 uppercase tracking-wider" style={{ color: "#475569" }}>Vai trò demo</div>
            <div className="grid grid-cols-3 gap-2">
              {(["student", "instructor", "admin"] as Role[]).map((r) => (
                <button
                  key={r}
                  onClick={() => setSelected(r)}
                  className="py-2 rounded text-xs font-medium transition-all border"
                  style={{
                    background: selected === r ? "rgba(99,102,241,0.2)" : "transparent",
                    borderColor: selected === r ? "#6366F1" : "#1E2A42",
                    color: selected === r ? "#818CF8" : "#64748B",
                  }}
                >
                  {r === "student" ? "Học viên" : r === "instructor" ? "Giảng viên" : "Admin"}
                </button>
              ))}
            </div>
          </div>

          {/* OAuth buttons */}
          <div className="flex flex-col gap-3">
            <button
              onClick={() => onLogin(selected)}
              className="flex items-center justify-center gap-3 py-3 px-4 rounded-lg font-medium text-sm transition-all"
              style={{ background: "#1a1a2e", border: "1px solid #2E3A52", color: "#E2E8F0" }}
              onMouseEnter={(e) => ((e.currentTarget as HTMLElement).style.borderColor = "#6366F1")}
              onMouseLeave={(e) => ((e.currentTarget as HTMLElement).style.borderColor = "#2E3A52")}
            >
              <GitFork size={18} />
              Tiếp tục với GitHub
            </button>
            <button
              onClick={() => onLogin(selected)}
              className="flex items-center justify-center gap-3 py-3 px-4 rounded-lg font-medium text-sm transition-all"
              style={{ background: "#6366F1", color: "#fff" }}
              onMouseEnter={(e) => ((e.currentTarget as HTMLElement).style.background = "#5557e8")}
              onMouseLeave={(e) => ((e.currentTarget as HTMLElement).style.background = "#6366F1")}
            >
              <Mail size={18} />
              Tiếp tục với Email
              <ArrowRight size={16} className="ml-auto" />
            </button>
          </div>

          <p className="text-xs text-center mt-5" style={{ color: "#334155" }}>
            Bằng cách đăng nhập, bạn đồng ý với{" "}
            <span style={{ color: "#6366F1", cursor: "pointer" }}>Điều khoản sử dụng</span>
          </p>
        </div>

        {/* Stats strip */}
        <div className="grid grid-cols-3 gap-4 mt-6">
          {[
            { v: "12,400+", l: "Học viên" },
            { v: "98%", l: "Hài lòng" },
            { v: "340+", l: "Bài học AI" },
          ].map((s) => (
            <div key={s.l} className="text-center">
              <div className="text-base font-bold" style={{ color: "#818CF8" }}>{s.v}</div>
              <div className="text-xs" style={{ color: "#475569" }}>{s.l}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
