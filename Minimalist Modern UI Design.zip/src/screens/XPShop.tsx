import { useState } from "react";
import { Star, Flame, Moon, Sparkles, Check, ShoppingBag } from "lucide-react";

const items = [
  {
    id: "streak-freeze",
    name: "Đóng băng Streak",
    desc: "Cứu chuỗi ngày khi bỏ lỡ 1 ngày học",
    cost: 200,
    icon: <Flame size={28} style={{ color: "#F59E0B" }} />,
    accent: "#F59E0B",
    bg: "rgba(245,158,11,0.08)",
    border: "rgba(245,158,11,0.2)",
    owned: 2,
  },
  {
    id: "dark-mode",
    name: "Giao diện Tối",
    desc: "Mở khóa Dark Mode nâng cao cho toàn bộ nền tảng",
    cost: 500,
    icon: <Moon size={28} style={{ color: "#818CF8" }} />,
    accent: "#818CF8",
    bg: "rgba(99,102,241,0.08)",
    border: "rgba(99,102,241,0.2)",
    owned: 0,
  },
  {
    id: "mino-gold",
    name: "Mino · Phiên bản Vàng",
    desc: "Đổi giao diện và tên của trợ giảng AI Mentor",
    cost: 800,
    icon: <Sparkles size={28} style={{ color: "#22D3EE" }} />,
    accent: "#22D3EE",
    bg: "rgba(34,211,238,0.08)",
    border: "rgba(34,211,238,0.2)",
    owned: 0,
  },
  {
    id: "xp-boost",
    name: "XP Boost x2",
    desc: "Nhân đôi XP nhận được trong 24 giờ tiếp theo",
    cost: 300,
    icon: <Star size={28} style={{ color: "#10B981" }} />,
    accent: "#10B981",
    bg: "rgba(16,185,129,0.08)",
    border: "rgba(16,185,129,0.2)",
    owned: 0,
  },
];

export default function XPShop() {
  const [xp, setXp] = useState(3240);
  const [purchased, setPurchased] = useState<Set<string>>(new Set());
  const [confirming, setConfirming] = useState<string | null>(null);

  const buy = (id: string, cost: number) => {
    if (xp < cost) return;
    setXp((x) => x - cost);
    setPurchased((p) => new Set([...p, id]));
    setConfirming(null);
  };

  return (
    <div className="p-6 max-w-3xl" style={{ background: "#07090F" }}>
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-lg font-semibold" style={{ color: "#E2E8F0" }}>XP Shop</h1>
          <p className="text-sm" style={{ color: "#475569" }}>Đổi điểm XP tích lũy lấy vật phẩm đặc biệt</p>
        </div>
        <div className="flex items-center gap-2 px-4 py-2 rounded-xl border"
          style={{ background: "rgba(34,211,238,0.08)", borderColor: "rgba(34,211,238,0.2)" }}>
          <Star size={16} style={{ color: "#22D3EE" }} />
          <span className="text-xl font-bold font-mono" style={{ color: "#22D3EE" }}>{xp.toLocaleString()}</span>
          <span className="text-sm" style={{ color: "#164E63" }}>XP</span>
        </div>
      </div>

      {/* XP bar */}
      <div className="rounded-xl border p-4 mb-6" style={{ background: "#0D1120", borderColor: "#1E2A42" }}>
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs" style={{ color: "#475569" }}>Level 8 — Tiến tới Level 9</span>
          <span className="text-xs font-mono" style={{ color: "#22D3EE" }}>3,240 / 4,000 XP</span>
        </div>
        <div className="rounded-full overflow-hidden" style={{ height: 6, background: "#1E2A42" }}>
          <div className="h-full rounded-full" style={{ width: "81%", background: "linear-gradient(90deg, #6366F1, #22D3EE)" }} />
        </div>
      </div>

      {/* Items grid */}
      <div className="grid gap-4" style={{ gridTemplateColumns: "repeat(2, 1fr)" }}>
        {items.map((item) => {
          const canAfford = xp >= item.cost;
          const isPurchased = purchased.has(item.id);
          const isConfirming = confirming === item.id;

          return (
            <div
              key={item.id}
              className="rounded-xl border p-5 flex flex-col transition-all"
              style={{
                background: item.bg,
                borderColor: item.border,
              }}
            >
              <div className="flex items-start justify-between mb-3">
                <div className="p-2 rounded-xl" style={{ background: "rgba(0,0,0,0.3)" }}>
                  {item.icon}
                </div>
                {item.owned > 0 && (
                  <span className="text-xs px-2 py-0.5 rounded-full font-mono"
                    style={{ background: "rgba(16,185,129,0.15)", color: "#10B981" }}>
                    Có {item.owned}
                  </span>
                )}
              </div>

              <div className="font-semibold text-sm mb-1" style={{ color: "#E2E8F0" }}>{item.name}</div>
              <div className="text-xs leading-relaxed flex-1 mb-4" style={{ color: "#64748B" }}>{item.desc}</div>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1">
                  <Star size={13} style={{ color: "#22D3EE" }} />
                  <span className="font-mono font-bold text-sm" style={{ color: "#22D3EE" }}>{item.cost}</span>
                  <span className="text-xs" style={{ color: "#334155" }}>XP</span>
                </div>

                {isPurchased ? (
                  <span className="flex items-center gap-1 text-xs px-3 py-1.5 rounded-lg"
                    style={{ background: "rgba(16,185,129,0.15)", color: "#10B981" }}>
                    <Check size={12} /> Đã mua
                  </span>
                ) : isConfirming ? (
                  <div className="flex gap-1.5">
                    <button
                      onClick={() => setConfirming(null)}
                      className="px-2 py-1.5 rounded-lg text-xs border"
                      style={{ borderColor: "#1E2A42", color: "#64748B" }}
                    >
                      Hủy
                    </button>
                    <button
                      onClick={() => buy(item.id, item.cost)}
                      className="px-2 py-1.5 rounded-lg text-xs font-medium"
                      style={{ background: item.accent, color: "#07090F" }}
                    >
                      Xác nhận
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => canAfford && setConfirming(item.id)}
                    disabled={!canAfford}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all"
                    style={{
                      background: canAfford ? item.accent : "#1E2A42",
                      color: canAfford ? "#07090F" : "#475569",
                      cursor: canAfford ? "pointer" : "not-allowed",
                    }}
                  >
                    <ShoppingBag size={12} />
                    {canAfford ? "Mua ngay" : "Không đủ XP"}
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Earn more */}
      <div className="mt-5 rounded-xl border p-4" style={{ background: "#0D1120", borderColor: "#1E2A42" }}>
        <div className="text-xs font-medium mb-2" style={{ color: "#475569" }}>Kiếm thêm XP</div>
        <div className="grid gap-2" style={{ gridTemplateColumns: "repeat(3,1fr)" }}>
          {[
            { label: "Hoàn thành Quiz", xp: "+50" },
            { label: "Vẽ Mindmap", xp: "+200" },
            { label: "Duy trì Streak", xp: "+30/ngày" },
          ].map((e) => (
            <div key={e.label} className="text-center p-2 rounded-lg" style={{ background: "#07090F" }}>
              <div className="text-xs font-bold font-mono" style={{ color: "#22D3EE" }}>{e.xp}</div>
              <div className="text-xs" style={{ color: "#475569", fontSize: 10 }}>{e.label}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
