import { useState } from "react";
import { Users, BookOpen, TrendingUp, Cpu, Search, MoreHorizontal, CheckCircle, XCircle, Clock, Shield } from "lucide-react";

type Tab = "overview" | "users" | "classes" | "sessions";

const stats = [
  { label: "Học viên hoạt động", value: "1,247", delta: "+48 hôm nay", icon: <Users size={16} />, color: "#6366F1" },
  { label: "Giảng viên", value: "28", delta: "3 chờ kích hoạt", icon: <BookOpen size={16} />, color: "#22D3EE" },
  { label: "Chi phí AI/tháng", value: "$342", delta: "↑ 12% so tháng trước", icon: <Cpu size={16} />, color: "#F59E0B" },
  { label: "Streak hoàn thành", value: "68%", delta: "Tỷ lệ hôm nay", icon: <TrendingUp size={16} />, color: "#10B981" },
];

const pendingEnrollments = [
  { name: "Nguyễn Minh Khôi", id: "SV-2024-0341", class: "OOP-Nhóm 01", time: "2 phút trước" },
  { name: "Trần Thị Lan Anh", id: "SV-2024-0528", class: "OOP-Nhóm 02", time: "14 phút trước" },
  { name: "Phạm Văn Đức", id: "SV-2024-0719", class: "DS-Nhóm 01", time: "1 giờ trước" },
];

const users = [
  { name: "Trần Thị B", role: "Giảng viên", email: "ttb@edu.vn", status: "active", lastActive: "Vừa xong" },
  { name: "Lê Văn C", role: "Học viên", email: "lvc@student.vn", status: "active", lastActive: "5 phút trước" },
  { name: "Hoàng Ngọc D", role: "Học viên", email: "hnd@student.vn", status: "suspended", lastActive: "3 ngày trước" },
  { name: "Võ Thị E", role: "Giảng viên", email: "vte@edu.vn", status: "pending", lastActive: "Chưa kích hoạt" },
  { name: "Đặng Văn F", role: "Học viên", email: "dvf@student.vn", status: "active", lastActive: "1 giờ trước" },
];

export default function AdminDashboard() {
  const [tab, setTab] = useState<Tab>("overview");
  const [search, setSearch] = useState("");
  const [pendingList, setPendingList] = useState(pendingEnrollments);

  const filtered = users.filter((u) =>
    u.name.toLowerCase().includes(search.toLowerCase()) ||
    u.email.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="p-6 min-h-full" style={{ background: "#07090F" }}>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-lg font-semibold" style={{ color: "#E2E8F0" }}>Quản trị hệ thống</h1>
          <p className="text-sm" style={{ color: "#475569" }}>CODE-MIND AIO · Bảng điều khiển Admin</p>
        </div>
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg border" style={{ background: "rgba(239,68,68,0.08)", borderColor: "rgba(239,68,68,0.2)" }}>
          <Shield size={13} style={{ color: "#EF4444" }} />
          <span className="text-xs font-medium" style={{ color: "#EF4444" }}>Admin Access</span>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 mb-5 border-b" style={{ borderColor: "#1E2A42" }}>
        {(["overview", "users", "classes", "sessions"] as Tab[]).map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className="px-4 py-2 text-xs font-medium border-b-2 transition-all"
            style={{
              borderColor: tab === t ? "#6366F1" : "transparent",
              color: tab === t ? "#818CF8" : "#475569",
              marginBottom: -1,
            }}
          >
            {t === "overview" ? "Tổng quan" : t === "users" ? "Người dùng" : t === "classes" ? "Lớp học" : "Phiên đăng nhập"}
          </button>
        ))}
      </div>

      {tab === "overview" && (
        <>
          {/* Stats */}
          <div className="grid gap-4 mb-5" style={{ gridTemplateColumns: "repeat(4,1fr)" }}>
            {stats.map((s) => (
              <div key={s.label} className="rounded-xl border p-4" style={{ background: "#0D1120", borderColor: "#1E2A42" }}>
                <div className="flex items-center justify-between mb-3">
                  <div className="p-1.5 rounded-lg" style={{ background: `${s.color}18`, color: s.color }}>{s.icon}</div>
                </div>
                <div className="text-xl font-bold font-mono" style={{ color: "#E2E8F0" }}>{s.value}</div>
                <div className="text-xs mt-0.5" style={{ color: "#64748B" }}>{s.label}</div>
                <div className="text-xs mt-1" style={{ color: s.color, fontSize: 10 }}>{s.delta}</div>
              </div>
            ))}
          </div>

          {/* Pending enrollments */}
          <div className="rounded-xl border p-4" style={{ background: "#0D1120", borderColor: "#1E2A42" }}>
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm font-medium" style={{ color: "#E2E8F0" }}>Yêu cầu tham gia lớp chờ duyệt</span>
              <span className="text-xs px-2 py-0.5 rounded-full" style={{ background: "rgba(245,158,11,0.15)", color: "#F59E0B" }}>
                {pendingList.length} chờ
              </span>
            </div>
            {pendingList.length === 0 ? (
              <div className="text-center py-6 text-sm" style={{ color: "#334155" }}>Không có yêu cầu nào</div>
            ) : (
              <div className="flex flex-col gap-2">
                {pendingList.map((e, i) => (
                  <div
                    key={i}
                    className="flex items-center gap-3 p-3 rounded-lg border"
                    style={{ background: "#07090F", borderColor: "#1E2A42" }}
                  >
                    <div className="rounded-full flex items-center justify-center text-xs font-bold shrink-0"
                      style={{ width: 32, height: 32, background: "#1E2A42", color: "#818CF8" }}>
                      {e.name.split(" ").slice(-1)[0][0]}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium truncate" style={{ color: "#CBD5E1" }}>{e.name}</div>
                      <div className="text-xs" style={{ color: "#475569" }}>{e.id} · {e.class} · {e.time}</div>
                    </div>
                    <div className="flex gap-1.5">
                      <button
                        onClick={() => setPendingList((l) => l.filter((_, j) => j !== i))}
                        className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium"
                        style={{ background: "rgba(16,185,129,0.15)", color: "#10B981" }}
                      >
                        <CheckCircle size={12} /> Duyệt
                      </button>
                      <button
                        onClick={() => setPendingList((l) => l.filter((_, j) => j !== i))}
                        className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs"
                        style={{ background: "rgba(239,68,68,0.1)", color: "#EF4444" }}
                      >
                        <XCircle size={12} /> Từ chối
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </>
      )}

      {tab === "users" && (
        <div className="rounded-xl border overflow-hidden" style={{ background: "#0D1120", borderColor: "#1E2A42" }}>
          <div className="flex items-center gap-3 px-4 py-3 border-b" style={{ borderColor: "#1E2A42" }}>
            <div className="flex items-center gap-2 flex-1 rounded-lg border px-3 py-1.5" style={{ background: "#07090F", borderColor: "#1E2A42" }}>
              <Search size={13} style={{ color: "#475569" }} />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Tìm theo tên hoặc email..."
                className="flex-1 bg-transparent text-sm outline-none"
                style={{ color: "#CBD5E1", fontSize: 13 }}
              />
            </div>
            <button className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium"
              style={{ background: "#6366F1", color: "#fff" }}>
              + Thêm giảng viên
            </button>
          </div>
          <table className="w-full">
            <thead>
              <tr style={{ borderBottom: "1px solid #1E2A42" }}>
                {["Tên", "Vai trò", "Email", "Trạng thái", "Hoạt động cuối", ""].map((h) => (
                  <th key={h} className="px-4 py-2.5 text-left text-xs font-medium uppercase tracking-wider" style={{ color: "#475569" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((u, i) => (
                <tr key={i} className="border-b transition-colors" style={{ borderColor: "#1E2A42" }}
                  onMouseEnter={(e) => (e.currentTarget.style.background = "#0F1629")}
                  onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
                >
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <div className="rounded-full flex items-center justify-center text-xs font-bold shrink-0"
                        style={{ width: 28, height: 28, background: "#1E2A42", color: "#818CF8" }}>
                        {u.name[0]}
                      </div>
                      <span className="text-sm" style={{ color: "#CBD5E1" }}>{u.name}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <span className="text-xs px-2 py-0.5 rounded"
                      style={{ background: u.role === "Admin" ? "rgba(239,68,68,0.12)" : u.role === "Giảng viên" ? "rgba(245,158,11,0.12)" : "rgba(99,102,241,0.12)", color: u.role === "Admin" ? "#EF4444" : u.role === "Giảng viên" ? "#F59E0B" : "#818CF8" }}>
                      {u.role}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-xs font-mono" style={{ color: "#475569" }}>{u.email}</td>
                  <td className="px-4 py-3">
                    <span className="flex items-center gap-1 text-xs">
                      {u.status === "active" ? <CheckCircle size={11} style={{ color: "#10B981" }} /> :
                        u.status === "suspended" ? <XCircle size={11} style={{ color: "#EF4444" }} /> :
                          <Clock size={11} style={{ color: "#F59E0B" }} />}
                      <span style={{ color: u.status === "active" ? "#10B981" : u.status === "suspended" ? "#EF4444" : "#F59E0B" }}>
                        {u.status === "active" ? "Hoạt động" : u.status === "suspended" ? "Bị khóa" : "Chờ kích hoạt"}
                      </span>
                    </span>
                  </td>
                  <td className="px-4 py-3 text-xs" style={{ color: "#475569" }}>{u.lastActive}</td>
                  <td className="px-4 py-3">
                    <button style={{ color: "#475569" }}><MoreHorizontal size={15} /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {tab === "classes" && (
        <div className="grid gap-4" style={{ gridTemplateColumns: "repeat(3,1fr)" }}>
          {[
            { code: "CM-OOP-2026-01", name: "Lập trình OOP — Nhóm 01", instructor: "Trần Thị B", students: 34, active: true },
            { code: "CM-OOP-2026-02", name: "Lập trình OOP — Nhóm 02", instructor: "Lê Văn C", students: 28, active: true },
            { code: "CM-DS-2026-01", name: "Cấu trúc Dữ liệu — Nhóm 01", instructor: "Trần Thị B", students: 41, active: false },
          ].map((c) => (
            <div key={c.code} className="rounded-xl border p-4" style={{ background: "#0D1120", borderColor: "#1E2A42" }}>
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-mono px-2 py-0.5 rounded" style={{ background: "#1E2A42", color: "#475569" }}>{c.code}</span>
                <span className="text-xs" style={{ color: c.active ? "#10B981" : "#475569" }}>{c.active ? "Đang mở" : "Đã đóng"}</span>
              </div>
              <div className="text-sm font-medium mb-1" style={{ color: "#E2E8F0" }}>{c.name}</div>
              <div className="text-xs mb-3" style={{ color: "#475569" }}>GV: {c.instructor}</div>
              <div className="flex items-center justify-between">
                <span className="text-xs" style={{ color: "#64748B" }}>{c.students} học viên</span>
                <button className="text-xs px-2 py-1 rounded" style={{ background: "rgba(99,102,241,0.12)", color: "#818CF8" }}>Xem lớp</button>
              </div>
            </div>
          ))}
        </div>
      )}

      {tab === "sessions" && (
        <div className="rounded-xl border overflow-hidden" style={{ background: "#0D1120", borderColor: "#1E2A42" }}>
          <div className="px-4 py-3 border-b" style={{ borderColor: "#1E2A42" }}>
            <span className="text-sm font-medium" style={{ color: "#E2E8F0" }}>Phiên đăng nhập đang hoạt động</span>
          </div>
          {[
            { name: "Nguyễn Văn A", device: "MacBook Pro · Chrome 128", ip: "192.168.1.42", time: "Hoạt động" },
            { name: "Trần Thị B", device: "Windows 11 · Edge 127", ip: "10.0.0.15", time: "5 phút trước" },
            { name: "Phạm Văn Đức", device: "iPhone 16 · Safari", ip: "172.16.0.8", time: "Hoạt động" },
          ].map((s, i) => (
            <div key={i} className="flex items-center gap-3 px-4 py-3 border-b" style={{ borderColor: "#1E2A42" }}>
              <div className="rounded-full flex items-center justify-center text-xs font-bold shrink-0"
                style={{ width: 30, height: 30, background: "#1E2A42", color: "#818CF8" }}>{s.name[0]}</div>
              <div className="flex-1">
                <div className="text-sm" style={{ color: "#CBD5E1" }}>{s.name}</div>
                <div className="text-xs" style={{ color: "#475569" }}>{s.device} · {s.ip}</div>
              </div>
              <div className="flex items-center gap-1 text-xs" style={{ color: s.time === "Hoạt động" ? "#10B981" : "#475569" }}>
                <div className="rounded-full" style={{ width: 6, height: 6, background: s.time === "Hoạt động" ? "#10B981" : "#334155" }} />
                {s.time}
              </div>
              <button className="text-xs px-2 py-1 rounded" style={{ background: "rgba(239,68,68,0.1)", color: "#EF4444" }}>
                Reset thiết bị
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
