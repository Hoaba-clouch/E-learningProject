import { useState } from "react";
import { Heart, MessageCircle, Bookmark, Share2, BookOpen, ChevronUp, ChevronDown, X, CheckCircle2 } from "lucide-react";

const reels = [
  {
    id: 1,
    title: "TypeScript 5.8 ra mắt với tính năng Type Narrowing cực mạnh",
    tags: ["#TypeScript", "#JavaScript", "#Frontend"],
    views: "12.4K",
    likes: 847,
    quiz: { q: "TypeScript là superset của ngôn ngữ nào?", options: ["Java", "JavaScript", "Python", "C#"], correct: 1 },
    gradient: "linear-gradient(160deg, #1a0533 0%, #0D1120 60%)",
    accent: "#818CF8",
  },
  {
    id: 2,
    title: "GitHub Copilot Agent Mode — AI code review tự động cho Pull Request",
    tags: ["#GitHub", "#AI", "#DevTools"],
    views: "28.1K",
    likes: 1203,
    quiz: { q: "GitHub Copilot dùng model AI nào làm nền tảng chính?", options: ["GPT-4", "Claude", "Gemini", "LLaMA"], correct: 0 },
    gradient: "linear-gradient(160deg, #001a0d 0%, #0D1120 60%)",
    accent: "#10B981",
  },
  {
    id: 3,
    title: "Rust vượt qua Python trong top ngôn ngữ được yêu thích nhất Stack Overflow 2026",
    tags: ["#Rust", "#Python", "#Survey"],
    views: "9.7K",
    likes: 634,
    quiz: { q: "Rust nổi tiếng với tính năng quản lý bộ nhớ nào?", options: ["Garbage Collection", "Ownership System", "Manual Free", "ARC"], correct: 1 },
    gradient: "linear-gradient(160deg, #1a0d00 0%, #0D1120 60%)",
    accent: "#F59E0B",
  },
];

export default function TechReels() {
  const [current, setCurrent] = useState(0);
  const [liked, setLiked] = useState<Set<number>>(new Set());
  const [saved, setSaved] = useState<Set<number>>(new Set());
  const [showQuiz, setShowQuiz] = useState(false);
  const [selected, setSelected] = useState<number | null>(null);
  const [answered, setAnswered] = useState<Set<number>>(new Set());

  const reel = reels[current];

  const nav = (dir: 1 | -1) => {
    setCurrent((c) => Math.max(0, Math.min(reels.length - 1, c + dir)));
    setShowQuiz(false);
    setSelected(null);
  };

  return (
    <div className="flex items-center justify-center h-full" style={{ background: "#07090F" }}>
      <div className="flex gap-6 items-center">
        {/* Reel card */}
        <div
          className="relative rounded-2xl overflow-hidden flex flex-col"
          style={{ width: 340, height: 600, background: reel.gradient }}
        >
          {/* Content */}
          <div className="flex-1 flex flex-col justify-end p-5">
            <div className="flex gap-1.5 flex-wrap mb-3">
              {reel.tags.map((t) => (
                <span key={t} className="text-xs px-2 py-0.5 rounded-full"
                  style={{ background: "rgba(255,255,255,0.1)", color: "#94A3B8" }}>{t}</span>
              ))}
            </div>
            <h2 className="text-base font-semibold leading-snug mb-2" style={{ color: "#E2E8F0" }}>{reel.title}</h2>
            <div className="text-xs mb-4" style={{ color: "#475569" }}>
              🤖 AI tổng hợp từ Hacker News · {reel.views} lượt xem
            </div>

            {/* Video placeholder */}
            <div className="rounded-xl overflow-hidden mb-4 flex items-center justify-center"
              style={{ height: 180, background: "rgba(0,0,0,0.4)", border: "1px solid rgba(255,255,255,0.08)" }}>
              <div style={{ color: "#475569", fontSize: 12 }}>▶ 0:30 · Video AI</div>
            </div>

            {/* Quiz trigger */}
            {!showQuiz ? (
              <button
                onClick={() => setShowQuiz(true)}
                className="w-full py-2.5 rounded-lg text-sm font-medium transition-all"
                style={{ background: reel.accent, color: "#07090F" }}
              >
                Quiz nhanh · +10 XP
              </button>
            ) : (
              <div className="rounded-xl p-3" style={{ background: "rgba(0,0,0,0.5)", border: "1px solid rgba(255,255,255,0.1)" }}>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-medium" style={{ color: "#E2E8F0" }}>{reel.quiz.q}</span>
                  <button onClick={() => setShowQuiz(false)}><X size={12} style={{ color: "#475569" }} /></button>
                </div>
                <div className="flex flex-col gap-1.5">
                  {reel.quiz.options.map((opt, i) => {
                    const isAnswered = answered.has(reel.id);
                    const isCorrect = i === reel.quiz.correct;
                    return (
                      <button
                        key={i}
                        onClick={() => {
                          if (!isAnswered) {
                            setSelected(i);
                            setAnswered((a) => new Set([...a, reel.id]));
                          }
                        }}
                        className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-xs text-left transition-all border"
                        style={{
                          background: isAnswered
                            ? isCorrect ? "rgba(16,185,129,0.2)" : selected === i ? "rgba(239,68,68,0.2)" : "rgba(0,0,0,0.3)"
                            : selected === i ? "rgba(99,102,241,0.2)" : "rgba(0,0,0,0.3)",
                          borderColor: isAnswered
                            ? isCorrect ? "rgba(16,185,129,0.4)" : selected === i ? "rgba(239,68,68,0.3)" : "transparent"
                            : selected === i ? "rgba(99,102,241,0.5)" : "transparent",
                          color: "#CBD5E1",
                        }}
                      >
                        {isAnswered && isCorrect && <CheckCircle2 size={11} style={{ color: "#10B981" }} />}
                        {opt}
                      </button>
                    );
                  })}
                </div>
                {answered.has(reel.id) && (
                  <div className="mt-2 text-center text-xs" style={{ color: selected === reel.quiz.correct ? "#10B981" : "#EF4444" }}>
                    {selected === reel.quiz.correct ? "+10 XP đã cộng! 🎉" : "Sai rồi — thử lại lần sau nhé"}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Overlay top bar */}
          <div className="absolute top-0 left-0 right-0 flex items-center px-4 py-3">
            <div
              className="px-2 py-1 rounded-full text-xs font-bold"
              style={{ background: "rgba(99,102,241,0.9)", color: "#fff" }}
            >
              LIVE
            </div>
            <div className="flex gap-1 ml-3 flex-1">
              {reels.map((_, i) => (
                <div key={i} className="rounded-full flex-1 h-0.5"
                  style={{ background: i === current ? "#fff" : "rgba(255,255,255,0.25)" }} />
              ))}
            </div>
          </div>
        </div>

        {/* Action buttons */}
        <div className="flex flex-col gap-5">
          <button
            onClick={() => nav(-1)}
            disabled={current === 0}
            className="flex items-center justify-center rounded-full transition-colors"
            style={{ width: 40, height: 40, background: "#1E2A42", color: current === 0 ? "#334155" : "#94A3B8" }}
          >
            <ChevronUp size={18} />
          </button>

          {[
            {
              icon: <Heart size={20} fill={liked.has(reel.id) ? "#EF4444" : "none"} />,
              label: (reel.likes + (liked.has(reel.id) ? 1 : 0)).toLocaleString(),
              color: liked.has(reel.id) ? "#EF4444" : "#64748B",
              action: () => setLiked((l) => { const n = new Set(l); n.has(reel.id) ? n.delete(reel.id) : n.add(reel.id); return n; }),
            },
            { icon: <MessageCircle size={20} />, label: "48", color: "#64748B", action: () => {} },
            {
              icon: <Bookmark size={20} fill={saved.has(reel.id) ? "#F59E0B" : "none"} />,
              label: "Lưu",
              color: saved.has(reel.id) ? "#F59E0B" : "#64748B",
              action: () => setSaved((s) => { const n = new Set(s); n.has(reel.id) ? n.delete(reel.id) : n.add(reel.id); return n; }),
            },
            { icon: <Share2 size={20} />, label: "Chia sẻ", color: "#64748B", action: () => {} },
            { icon: <BookOpen size={20} />, label: "Học sâu", color: "#6366F1", action: () => {} },
          ].map((btn, i) => (
            <div key={i} className="flex flex-col items-center gap-1">
              <button
                onClick={btn.action}
                className="flex items-center justify-center rounded-full transition-all"
                style={{ width: 44, height: 44, background: "#0D1120", border: "1px solid #1E2A42", color: btn.color }}
                onMouseEnter={(e) => ((e.currentTarget as HTMLElement).style.borderColor = "#2E3A52")}
                onMouseLeave={(e) => ((e.currentTarget as HTMLElement).style.borderColor = "#1E2A42")}
              >
                {btn.icon}
              </button>
              <span className="text-xs" style={{ color: "#475569" }}>{btn.label}</span>
            </div>
          ))}

          <button
            onClick={() => nav(1)}
            disabled={current === reels.length - 1}
            className="flex items-center justify-center rounded-full transition-colors"
            style={{ width: 40, height: 40, background: "#1E2A42", color: current === reels.length - 1 ? "#334155" : "#94A3B8" }}
          >
            <ChevronDown size={18} />
          </button>
        </div>
      </div>
    </div>
  );
}
