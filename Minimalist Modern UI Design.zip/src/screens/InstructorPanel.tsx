import { useState } from "react";
import { BookOpen, GitFork, BarChart3, Plus, Upload, CheckCircle2, AlertTriangle, XCircle, Flag, Eye } from "lucide-react";

type Tab = "syllabus" | "github-review" | "heatmap";

const submissions = [
  { name: "Nguyễn Minh Khôi", score: null, flag: "plagiarism", integrity: 41, submitted: "2 giờ trước" },
  { name: "Trần Thị Lan Anh", score: 88, flag: null, integrity: 91, submitted: "5 giờ trước" },
  { name: "Phạm Văn Đức", score: null, flag: "commit", integrity: 62, submitted: "1 ngày trước" },
  { name: "Lê Bảo Châu", score: 76, flag: null, integrity: 83, submitted: "1 ngày trước" },
  { name: "Võ Ngọc Hà", score: null, flag: null, integrity: 78, submitted: "2 ngày trước" },
];

const chapters = [
  {
    id: 1, title: "Chương 1: Kế thừa", published: true,
    lessons: [
      { title: "1.1 Khái niệm Kế thừa", status: "published" },
      { title: "1.2 extends và super", status: "published" },
      { title: "1.3 Override methods", status: "draft" },
    ],
  },
  {
    id: 2, title: "Chương 2: Đa hình", published: false,
    lessons: [
      { title: "2.1 Đa hình thời gian chạy", status: "draft" },
    ],
  },
];

// Heatmap nodes — heat: 0-100
const heatNodes = [
  { label: "Kế thừa cơ bản", heat: 18, x: 50, y: 10 },
  { label: "extends", heat: 25, x: 30, y: 28 },
  { label: "super()", heat: 72, x: 65, y: 28 },
  { label: "Override", heat: 85, x: 20, y: 48 },
  { label: "Polymorphism", heat: 91, x: 55, y: 48 },
  { label: "Abstract class", heat: 60, x: 80, y: 48 },
];

const heatColor = (h: number) =>
  h >= 80 ? "#EF4444" : h >= 60 ? "#F59E0B" : h >= 40 ? "#EAB308" : "#10B981";

export default function InstructorPanel() {
  const [tab, setTab] = useState<Tab>("syllabus");
  const [selectedSub, setSelectedSub] = useState<number | null>(null);

  return (
    <div className="p-6 min-h-full" style={{ background: "#07090F" }}>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-lg font-semibold" style={{ color: "#E2E8F0" }}>Bảng điều khiển Giảng viên</h1>
          <p className="text-sm" style={{ color: "#475569" }}>Lập trình OOP — Nhóm 01 · CM-OOP-2026-01</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 mb-5 border-b" style={{ borderColor: "#1E2A42" }}>
        {([
          { id: "syllabus", label: "Cấu trúc khóa học", icon: <BookOpen size={13} /> },
          { id: "github-review", label: "Chấm bài GitHub", icon: <GitFork size={13} /> },
          { id: "heatmap", label: "Nhiệt đồ lớp học", icon: <BarChart3 size={13} /> },
        ] as { id: Tab; label: string; icon: React.ReactNode }[]).map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className="flex items-center gap-2 px-4 py-2 text-xs font-medium border-b-2 transition-all"
            style={{
              borderColor: tab === t.id ? "#6366F1" : "transparent",
              color: tab === t.id ? "#818CF8" : "#475569",
              marginBottom: -1,
            }}
          >
            {t.icon} {t.label}
          </button>
        ))}
      </div>

      {/* Syllabus */}
      {tab === "syllabus" && (
        <div className="flex flex-col gap-4">
          {chapters.map((ch) => (
            <div key={ch.id} className="rounded-xl border overflow-hidden" style={{ background: "#0D1120", borderColor: "#1E2A42" }}>
              <div className="flex items-center justify-between px-4 py-3 border-b" style={{ borderColor: "#1E2A42" }}>
                <div className="flex items-center gap-3">
                  <span className="text-sm font-semibold" style={{ color: "#E2E8F0" }}>{ch.title}</span>
                  <span className="text-xs px-2 py-0.5 rounded"
                    style={{ background: ch.published ? "rgba(16,185,129,0.12)" : "rgba(245,158,11,0.12)", color: ch.published ? "#10B981" : "#F59E0B" }}>
                    {ch.published ? "Đã phát hành" : "Bản nháp"}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <button className="flex items-center gap-1.5 px-2.5 py-1.5 rounded text-xs border transition-colors"
                    style={{ borderColor: "#1E2A42", color: "#64748B" }}>
                    <Upload size={11} /> Tạo bài giảng AI
                  </button>
                  <button className="flex items-center gap-1.5 px-2.5 py-1.5 rounded text-xs"
                    style={{ background: "rgba(99,102,241,0.15)", color: "#818CF8" }}>
                    <Plus size={11} /> Thêm bài học
                  </button>
                </div>
              </div>
              <div className="p-3 flex flex-col gap-1.5">
                {ch.lessons.map((l, i) => (
                  <div key={i} className="flex items-center justify-between px-3 py-2 rounded-lg"
                    style={{ background: "#07090F" }}>
                    <div className="flex items-center gap-2">
                      {l.status === "published" ?
                        <CheckCircle2 size={13} style={{ color: "#10B981" }} /> :
                        <div className="rounded-full" style={{ width: 13, height: 13, border: "1.5px solid #334155" }} />}
                      <span className="text-sm" style={{ color: l.status === "published" ? "#CBD5E1" : "#64748B" }}>{l.title}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="flex gap-1">
                        {["Bài đọc", "Video", "Quiz"].map((t) => (
                          <span key={t} className="text-xs px-1.5 py-0.5 rounded" style={{ background: "#1E2A42", color: "#475569", fontSize: 10 }}>{t}</span>
                        ))}
                      </div>
                      <span className="text-xs px-2 py-0.5 rounded"
                        style={{ background: l.status === "published" ? "rgba(16,185,129,0.1)" : "rgba(245,158,11,0.1)", color: l.status === "published" ? "#10B981" : "#F59E0B" }}>
                        {l.status === "published" ? "Phát hành" : "Nháp"}
                      </span>
                    </div>
                  </div>
                ))}
                <div className="flex items-center justify-between px-3 py-2 rounded-lg border border-dashed"
                  style={{ borderColor: "#1E2A42" }}>
                  <span className="text-xs" style={{ color: "#334155" }}>🧠 Mindmap tổng hợp chương (Tự chọn)</span>
                  <span className="text-xs" style={{ color: "#475569" }}>+200 XP</span>
                </div>
                <div className="flex items-center justify-between px-3 py-2 rounded-lg border border-dashed"
                  style={{ borderColor: "#1E2A42" }}>
                  <span className="text-xs" style={{ color: "#334155" }}>💻 Bài tập lớn GitHub (Bắt buộc)</span>
                  <span className="text-xs" style={{ color: "#475569" }}>Tính điểm chương</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* GitHub Review */}
      {tab === "github-review" && (
        <div className="grid gap-5" style={{ gridTemplateColumns: selectedSub !== null ? "1fr 380px" : "1fr" }}>
          <div className="rounded-xl border overflow-hidden" style={{ background: "#0D1120", borderColor: "#1E2A42" }}>
            <div className="px-4 py-3 border-b flex items-center justify-between" style={{ borderColor: "#1E2A42" }}>
              <span className="text-sm font-medium" style={{ color: "#E2E8F0" }}>Bài nộp Chương 1 — {submissions.length} học viên</span>
              <span className="text-xs px-2 py-0.5 rounded" style={{ background: "rgba(239,68,68,0.12)", color: "#EF4444" }}>
                {submissions.filter((s) => s.flag).length} cần xem xét
              </span>
            </div>
            <table className="w-full">
              <thead>
                <tr style={{ borderBottom: "1px solid #1E2A42" }}>
                  {["Học viên", "Trạng thái", "Integrity Score", "Nộp lúc", ""].map((h) => (
                    <th key={h} className="px-4 py-2.5 text-left text-xs font-medium uppercase tracking-wider" style={{ color: "#475569" }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {submissions.map((s, i) => (
                  <tr
                    key={i}
                    className="border-b transition-colors cursor-pointer"
                    style={{ borderColor: "#1E2A42", background: selectedSub === i ? "#0F1629" : "transparent" }}
                    onClick={() => setSelectedSub(selectedSub === i ? null : i)}
                    onMouseEnter={(e) => selectedSub !== i && (e.currentTarget.style.background = "#0a0f1c")}
                    onMouseLeave={(e) => selectedSub !== i && (e.currentTarget.style.background = "transparent")}
                  >
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <div className="rounded-full flex items-center justify-center text-xs font-bold shrink-0"
                          style={{ width: 28, height: 28, background: "#1E2A42", color: "#818CF8" }}>
                          {s.name[0]}
                        </div>
                        <span className="text-sm" style={{ color: "#CBD5E1" }}>{s.name}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      {s.flag === "plagiarism" ? (
                        <span className="flex items-center gap-1 text-xs" style={{ color: "#EF4444" }}><Flag size={11} /> Nghi vấn đạo văn</span>
                      ) : s.flag === "commit" ? (
                        <span className="flex items-center gap-1 text-xs" style={{ color: "#F59E0B" }}><AlertTriangle size={11} /> Commit bất thường</span>
                      ) : s.score ? (
                        <span className="flex items-center gap-1 text-xs" style={{ color: "#10B981" }}><CheckCircle2 size={11} /> Đã chấm</span>
                      ) : (
                        <span className="flex items-center gap-1 text-xs" style={{ color: "#6366F1" }}><Eye size={11} /> Chờ chấm</span>
                      )}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <div className="rounded-full overflow-hidden flex-1 max-w-24" style={{ height: 4, background: "#1E2A42" }}>
                          <div className="h-full rounded-full" style={{
                            width: `${s.integrity}%`,
                            background: s.integrity >= 80 ? "#10B981" : s.integrity >= 60 ? "#F59E0B" : "#EF4444"
                          }} />
                        </div>
                        <span className="text-xs font-mono" style={{ color: "#64748B" }}>{s.integrity}/100</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-xs" style={{ color: "#475569" }}>{s.submitted}</td>
                    <td className="px-4 py-3">
                      <span className="text-xs font-mono" style={{ color: s.score ? "#E2E8F0" : "#334155" }}>
                        {s.score ? `${s.score}/100` : "—"}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {selectedSub !== null && (
            <div className="rounded-xl border p-4 flex flex-col gap-4" style={{ background: "#0D1120", borderColor: "#1E2A42" }}>
              <div>
                <div className="text-sm font-semibold" style={{ color: "#E2E8F0" }}>{submissions[selectedSub].name}</div>
                <div className="text-xs mt-0.5" style={{ color: "#475569" }}>Chương 1 · Dự án thực hành Kế thừa</div>
              </div>
              {submissions[selectedSub].flag && (
                <div className="p-3 rounded-lg border" style={{
                  background: "rgba(239,68,68,0.06)",
                  borderColor: "rgba(239,68,68,0.25)"
                }}>
                  <div className="flex items-center gap-1.5 text-xs font-medium mb-1" style={{ color: "#EF4444" }}>
                    <Flag size={12} /> Cảnh báo AI
                  </div>
                  <p className="text-xs" style={{ color: "#7F1D1D" }}>
                    {submissions[selectedSub].flag === "plagiarism"
                      ? "Tỷ lệ trùng lặp code với Phạm Văn Đức đạt 67% (MOSS). Cần xem xét thủ công."
                      : "Phát hiện 3 commit lớn bất thường trong 10 phút cuối. Tiến trình commit không tự nhiên."}
                  </p>
                </div>
              )}
              <div>
                <div className="text-xs font-medium mb-1 uppercase tracking-wider" style={{ color: "#475569" }}>Repo GitHub</div>
                <div className="flex items-center gap-2 px-3 py-2 rounded-lg border font-mono text-xs" style={{ background: "#07090F", borderColor: "#1E2A42", color: "#818CF8" }}>
                  <GitFork size={12} />
                  github.com/student/oop-project-ch1
                </div>
              </div>
              <div>
                <div className="text-xs font-medium mb-2 uppercase tracking-wider" style={{ color: "#475569" }}>Nhập điểm</div>
                <input
                  type="number"
                  placeholder="0–100"
                  min={0} max={100}
                  className="w-full px-3 py-2 rounded-lg border text-sm font-mono outline-none"
                  style={{ background: "#07090F", borderColor: "#1E2A42", color: "#E2E8F0" }}
                />
              </div>
              <div>
                <div className="text-xs font-medium mb-2 uppercase tracking-wider" style={{ color: "#475569" }}>Nhận xét</div>
                <textarea rows={4}
                  placeholder="Ghi nhận xét chi tiết cho học viên..."
                  className="w-full px-3 py-2 rounded-lg border text-xs font-mono outline-none resize-none"
                  style={{ background: "#07090F", borderColor: "#1E2A42", color: "#CBD5E1" }}
                />
              </div>
              <button className="py-2.5 rounded-lg text-sm font-medium"
                style={{ background: "#6366F1", color: "#fff" }}>
                Gửi đánh giá
              </button>
            </div>
          )}
        </div>
      )}

      {/* Heatmap */}
      {tab === "heatmap" && (
        <div>
          <div className="flex items-center gap-3 mb-4">
            <div className="text-sm" style={{ color: "#E2E8F0" }}>Nhiệt đồ khái niệm — Chương 1: Kế thừa</div>
            <div className="flex items-center gap-2 ml-auto">
              {[
                { color: "#10B981", label: "< 40%" },
                { color: "#F59E0B", label: "40–60%" },
                { color: "#EF4444", label: "> 80%" },
              ].map((l) => (
                <div key={l.label} className="flex items-center gap-1">
                  <div className="rounded-sm" style={{ width: 10, height: 10, background: l.color }} />
                  <span className="text-xs" style={{ color: "#475569" }}>{l.label}</span>
                </div>
              ))}
              <span className="text-xs ml-1" style={{ color: "#334155" }}>Tỷ lệ sai tổng hợp</span>
            </div>
          </div>
          <div className="rounded-xl border p-6 relative" style={{ background: "#0D1120", borderColor: "#1E2A42", height: 400 }}>
            <svg className="absolute inset-0 w-full h-full" style={{ zIndex: 0 }}>
              {[
                [0, 1], [0, 2], [1, 3], [1, 4], [2, 4], [2, 5],
              ].map(([from, to], i) => {
                const f = heatNodes[from], t = heatNodes[to];
                return (
                  <line key={i}
                    x1={`${f.x}%`} y1={`${f.y + 5}%`}
                    x2={`${t.x}%`} y2={`${t.y - 5}%`}
                    stroke="#1E2A42" strokeWidth={1.5} opacity={0.7}
                  />
                );
              })}
            </svg>
            {heatNodes.map((node, i) => (
              <div
                key={i}
                className="absolute flex flex-col items-center cursor-pointer"
                style={{ left: `${node.x}%`, top: `${node.y}%`, transform: "translate(-50%,-50%)", zIndex: 1 }}
              >
                <div
                  className="rounded-full flex items-center justify-center text-xs font-bold transition-transform"
                  style={{
                    width: 52, height: 52,
                    background: heatColor(node.heat),
                    boxShadow: node.heat >= 80 ? `0 0 20px ${heatColor(node.heat)}55` : "none",
                    color: "#fff",
                    fontSize: 13,
                  }}
                  onMouseEnter={(e) => ((e.currentTarget as HTMLElement).style.transform = "scale(1.1)")}
                  onMouseLeave={(e) => ((e.currentTarget as HTMLElement).style.transform = "scale(1)")}
                >
                  {node.heat}%
                </div>
                <span className="mt-1.5 text-center" style={{ fontSize: 11, color: "#94A3B8", maxWidth: 80 }}>{node.label}</span>
              </div>
            ))}
          </div>
          <div className="mt-4 p-3 rounded-xl border" style={{ background: "rgba(239,68,68,0.06)", borderColor: "rgba(239,68,68,0.2)" }}>
            <div className="text-xs font-semibold mb-2" style={{ color: "#EF4444" }}>🔴 Hotspot — Cần giảng lại</div>
            <div className="grid gap-2" style={{ gridTemplateColumns: "repeat(2,1fr)" }}>
              {heatNodes.filter((n) => n.heat >= 60).map((n, i) => (
                <div key={i} className="flex items-center justify-between text-xs px-2 py-1.5 rounded" style={{ background: "#07090F" }}>
                  <span style={{ color: "#CBD5E1" }}>{n.label}</span>
                  <span style={{ color: heatColor(n.heat), fontFamily: "monospace" }}>{n.heat}% sai</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
