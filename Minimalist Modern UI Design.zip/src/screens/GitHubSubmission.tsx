import { useState } from "react";
import { GitFork, CheckCircle2, AlertTriangle, XCircle, Loader, ChevronRight, Link, GitBranch, FileText } from "lucide-react";

type Status = "idle" | "checking" | "done";

const layers = [
  { name: "Xác thực GitHub OAuth", desc: "Repo có commit của tài khoản nộp?" },
  { name: "Lịch sử commit", desc: "Quá trình commit có tự nhiên không?" },
  { name: "Quét đạo văn chéo (MOSS)", desc: "Mã nguồn giống bài khác trong lớp?" },
  { name: "Đối chiếu Logic Mindmap", desc: "Code có khớp sơ đồ Mindmap đã vẽ?" },
  { name: "Walkthrough bắt buộc", desc: "Giải thích code đủ rõ ràng không?" },
];

export default function GitHubSubmission() {
  const [repoUrl, setRepoUrl] = useState("");
  const [branch, setBranch] = useState("main");
  const [walkthrough, setWalkthrough] = useState("");
  const [status, setStatus] = useState<Status>("idle");
  const [layerStatus, setLayerStatus] = useState<("pending" | "ok" | "warn" | "error")[]>(layers.map(() => "pending"));
  const [currentLayer, setCurrentLayer] = useState(-1);

  const wordCount = walkthrough.trim().split(/\s+/).filter(Boolean).length;

  const runCheck = async () => {
    if (!repoUrl || wordCount < 100) return;
    setStatus("checking");
    setCurrentLayer(0);
    const results: ("ok" | "warn")[] = ["ok", "ok", "warn", "ok", "ok"];
    for (let i = 0; i < layers.length; i++) {
      await new Promise((r) => setTimeout(r, 800));
      setLayerStatus((prev) => { const n = [...prev]; n[i] = results[i]; return n; });
      setCurrentLayer(i + 1);
    }
    setStatus("done");
  };

  return (
    <div className="p-6 max-w-3xl" style={{ background: "#07090F" }}>
      <div className="mb-6">
        <h1 className="text-lg font-semibold" style={{ color: "#E2E8F0" }}>Nộp bài tập thực hành</h1>
        <p className="text-sm mt-0.5" style={{ color: "#475569" }}>
          Chương 1: Kế thừa — Dự án thực hành · Hệ thống kiểm tra 5 lớp bảo mật
        </p>
      </div>

      <div className="grid gap-5" style={{ gridTemplateColumns: "1fr 280px" }}>
        {/* Form */}
        <div className="flex flex-col gap-4">
          {/* Repo URL */}
          <div className="rounded-xl border p-4" style={{ background: "#0D1120", borderColor: "#1E2A42" }}>
            <label className="flex items-center gap-2 text-xs font-medium mb-2 uppercase tracking-wider" style={{ color: "#475569" }}>
              <Link size={12} /> Repository URL
            </label>
            <div className="flex items-center gap-2 rounded-lg border px-3 py-2" style={{ background: "#07090F", borderColor: "#1E2A42" }}>
              <GitFork size={14} style={{ color: "#475569" }} />
              <input
                value={repoUrl}
                onChange={(e) => setRepoUrl(e.target.value)}
                placeholder="https://github.com/username/oop-inheritance-project"
                className="flex-1 bg-transparent text-sm outline-none font-mono"
                style={{ color: "#E2E8F0", fontSize: 12 }}
              />
            </div>
          </div>

          {/* Branch */}
          <div className="rounded-xl border p-4" style={{ background: "#0D1120", borderColor: "#1E2A42" }}>
            <label className="flex items-center gap-2 text-xs font-medium mb-2 uppercase tracking-wider" style={{ color: "#475569" }}>
              <GitBranch size={12} /> Chọn Branch
            </label>
            <div className="flex gap-2">
              {["main", "develop", "submission"].map((b) => (
                <button
                  key={b}
                  onClick={() => setBranch(b)}
                  className="px-3 py-1.5 rounded border text-xs font-mono transition-all"
                  style={{
                    background: branch === b ? "rgba(99,102,241,0.15)" : "transparent",
                    borderColor: branch === b ? "#6366F1" : "#1E2A42",
                    color: branch === b ? "#818CF8" : "#475569",
                  }}
                >
                  {b}
                </button>
              ))}
            </div>
          </div>

          {/* Walkthrough */}
          <div className="rounded-xl border p-4" style={{ background: "#0D1120", borderColor: "#1E2A42" }}>
            <label className="flex items-center justify-between mb-2">
              <span className="flex items-center gap-2 text-xs font-medium uppercase tracking-wider" style={{ color: "#475569" }}>
                <FileText size={12} /> Giải thích code (Walkthrough)
              </span>
              <span
                className="text-xs font-mono"
                style={{ color: wordCount >= 100 ? "#10B981" : wordCount > 60 ? "#F59E0B" : "#EF4444" }}
              >
                {wordCount}/100 từ
              </span>
            </label>
            <textarea
              rows={8}
              value={walkthrough}
              onChange={(e) => setWalkthrough(e.target.value)}
              placeholder="Mô tả chi tiết cách bạn giải quyết bài toán: Lớp nào extends lớp nào, phương thức nào được override, tại sao bạn chọn thiết kế này...&#10;&#10;Tối thiểu 100 từ để vượt lớp kiểm tra."
              className="w-full rounded-lg border px-3 py-2.5 text-sm outline-none resize-none font-mono"
              style={{ background: "#07090F", borderColor: "#1E2A42", color: "#CBD5E1", fontSize: 12, lineHeight: 1.6 }}
            />
            {wordCount > 0 && wordCount < 100 && (
              <p className="text-xs mt-1.5" style={{ color: "#F59E0B" }}>
                Cần thêm {100 - wordCount} từ nữa để đáp ứng yêu cầu tối thiểu
              </p>
            )}
          </div>

          <button
            onClick={runCheck}
            disabled={!repoUrl || wordCount < 100 || status === "checking"}
            className="flex items-center justify-center gap-2 py-3 rounded-xl font-medium text-sm transition-all"
            style={{
              background: !repoUrl || wordCount < 100 || status === "checking" ? "#1E2A42" : "#6366F1",
              color: !repoUrl || wordCount < 100 || status === "checking" ? "#475569" : "#fff",
              cursor: !repoUrl || wordCount < 100 || status === "checking" ? "default" : "pointer",
            }}
          >
            {status === "checking" ? (
              <><Loader size={16} className="animate-spin" /> Đang kiểm tra 5 lớp bảo mật...</>
            ) : status === "done" ? (
              <><CheckCircle2 size={16} /> Xem kết quả</>
            ) : (
              <>Nộp bài <ChevronRight size={16} /></>
            )}
          </button>
        </div>

        {/* 5-layer checker */}
        <div className="rounded-xl border p-4" style={{ background: "#0D1120", borderColor: "#1E2A42" }}>
          <div className="text-xs font-medium mb-3 uppercase tracking-wider" style={{ color: "#475569" }}>
            Hệ thống kiểm tra 5 lớp
          </div>
          <div className="flex flex-col gap-2">
            {layers.map((layer, i) => {
              const ls = layerStatus[i];
              const isRunning = status === "checking" && currentLayer === i;
              return (
                <div
                  key={i}
                  className="flex items-start gap-2.5 p-2.5 rounded-lg transition-all"
                  style={{
                    background: ls === "ok" ? "rgba(16,185,129,0.06)" : ls === "warn" ? "rgba(245,158,11,0.06)" : ls === "error" ? "rgba(239,68,68,0.06)" : "transparent",
                  }}
                >
                  <div className="shrink-0 mt-0.5">
                    {isRunning ? <Loader size={14} className="animate-spin" style={{ color: "#6366F1" }} /> :
                      ls === "ok" ? <CheckCircle2 size={14} style={{ color: "#10B981" }} /> :
                        ls === "warn" ? <AlertTriangle size={14} style={{ color: "#F59E0B" }} /> :
                          ls === "error" ? <XCircle size={14} style={{ color: "#EF4444" }} /> :
                            <div className="rounded-full" style={{ width: 14, height: 14, border: "1.5px solid #334155" }} />}
                  </div>
                  <div>
                    <div className="text-xs font-medium" style={{ color: ls === "pending" ? "#475569" : "#CBD5E1" }}>
                      Lớp {i + 1}: {layer.name}
                    </div>
                    <div className="text-xs" style={{ color: "#334155", fontSize: 10, marginTop: 1 }}>{layer.desc}</div>
                    {ls === "warn" && (
                      <div className="text-xs mt-1" style={{ color: "#F59E0B", fontSize: 10 }}>
                        ⚠ Phát hiện 23% trùng lặp — Giảng viên sẽ xem xét
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {status === "done" && (
            <div className="mt-3 p-3 rounded-lg border" style={{
              background: "rgba(16,185,129,0.08)",
              borderColor: "rgba(16,185,129,0.25)"
            }}>
              <div className="text-xs font-semibold mb-0.5" style={{ color: "#10B981" }}>✓ Bài nộp hợp lệ</div>
              <div className="text-xs" style={{ color: "#475569" }}>Integrity Score: <span style={{ color: "#22D3EE", fontFamily: "monospace" }}>77/100</span></div>
              <div className="text-xs mt-0.5" style={{ color: "#475569" }}>Đang chờ giảng viên chấm điểm</div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
