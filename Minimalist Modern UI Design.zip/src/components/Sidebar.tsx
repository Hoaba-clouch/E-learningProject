import {
  LayoutDashboard, BookOpen, Play, GitFork, ShoppingBag,
  Shield, GraduationCap, LogOut, Zap, ChevronRight
} from "lucide-react";
import type { Screen, Role } from "../App";

interface Props {
  screen: Screen;
  role: Role;
  onNavigate: (s: Screen) => void;
  onLogout: () => void;
}

interface NavItem {
  id: Screen;
  label: string;
  icon: React.ReactNode;
  roles: Role[];
}

const items: NavItem[] = [
  { id: "student-dashboard", label: "Dashboard", icon: <LayoutDashboard size={16} />, roles: ["student"] },
  { id: "workspace", label: "Học tập", icon: <BookOpen size={16} />, roles: ["student"] },
  { id: "reels", label: "Tech Reels", icon: <Play size={16} />, roles: ["student"] },
  { id: "github", label: "Nộp bài", icon: <GitFork size={16} />, roles: ["student"] },
  { id: "xp-shop", label: "XP Shop", icon: <ShoppingBag size={16} />, roles: ["student"] },
  { id: "instructor", label: "Biên soạn", icon: <GraduationCap size={16} />, roles: ["instructor"] },
  { id: "admin", label: "Quản trị", icon: <Shield size={16} />, roles: ["admin"] },
];

export default function Sidebar({ screen, role, onNavigate, onLogout }: Props) {
  const visible = items.filter((i) => i.roles.includes(role));

  return (
    <aside
      className="flex flex-col shrink-0 border-r"
      style={{
        width: 200,
        background: "#07090F",
        borderColor: "#1E2A42",
      }}
    >
      {/* Logo */}
      <div className="flex items-center gap-2 px-4 py-5 border-b" style={{ borderColor: "#1E2A42" }}>
        <div
          className="flex items-center justify-center rounded"
          style={{ width: 28, height: 28, background: "#6366F1" }}
        >
          <Zap size={14} color="#fff" fill="#fff" />
        </div>
        <div>
          <div className="font-bold text-sm tracking-wide" style={{ color: "#E2E8F0", fontFamily: "monospace" }}>
            CODE<span style={{ color: "#6366F1" }}>·</span>MIND
          </div>
          <div className="text-xs" style={{ color: "#475569", fontSize: 10 }}>AIO Platform</div>
        </div>
      </div>

      {/* Role badge */}
      <div className="px-4 py-3">
        <span
          className="inline-flex items-center gap-1 px-2 py-1 rounded text-xs font-medium uppercase tracking-wider"
          style={{
            background: role === "admin" ? "rgba(239,68,68,0.12)" : role === "instructor" ? "rgba(245,158,11,0.12)" : "rgba(99,102,241,0.12)",
            color: role === "admin" ? "#EF4444" : role === "instructor" ? "#F59E0B" : "#818CF8",
            fontSize: 10,
          }}
        >
          {role === "admin" ? "Admin" : role === "instructor" ? "Giảng viên" : "Học viên"}
        </span>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-2 pb-4 flex flex-col gap-0.5">
        {visible.map((item) => {
          const active = screen === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className="flex items-center justify-between px-3 py-2 rounded text-left transition-all"
              style={{
                background: active ? "rgba(99,102,241,0.15)" : "transparent",
                color: active ? "#818CF8" : "#64748B",
                fontSize: 13,
              }}
              onMouseEnter={(e) => {
                if (!active) (e.currentTarget as HTMLElement).style.color = "#94A3B8";
              }}
              onMouseLeave={(e) => {
                if (!active) (e.currentTarget as HTMLElement).style.color = "#64748B";
              }}
            >
              <span className="flex items-center gap-2.5">
                {item.icon}
                {item.label}
              </span>
              {active && <ChevronRight size={12} />}
            </button>
          );
        })}
      </nav>

      {/* User */}
      <div className="border-t px-3 py-3" style={{ borderColor: "#1E2A42" }}>
        <div className="flex items-center gap-2 mb-3">
          <div
            className="rounded-full flex items-center justify-center text-xs font-bold shrink-0"
            style={{ width: 28, height: 28, background: "#1E2A42", color: "#818CF8" }}
          >
            NV
          </div>
          <div className="min-w-0">
            <div className="text-xs font-medium truncate" style={{ color: "#CBD5E1" }}>Nguyễn Văn A</div>
            <div className="text-xs truncate" style={{ color: "#475569", fontSize: 10 }}>n.vana@email.com</div>
          </div>
        </div>
        <button
          onClick={onLogout}
          className="flex items-center gap-2 w-full px-2 py-1.5 rounded text-xs transition-colors"
          style={{ color: "#475569" }}
          onMouseEnter={(e) => ((e.currentTarget as HTMLElement).style.color = "#EF4444")}
          onMouseLeave={(e) => ((e.currentTarget as HTMLElement).style.color = "#475569")}
        >
          <LogOut size={13} />
          Đăng xuất
        </button>
      </div>
    </aside>
  );
}
