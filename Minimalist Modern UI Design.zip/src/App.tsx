import { useState } from "react";
import Sidebar from "./components/Sidebar";
import LoginScreen from "./screens/LoginScreen";
import StudentDashboard from "./screens/StudentDashboard";
import LearningWorkspace from "./screens/LearningWorkspace";
import TechReels from "./screens/TechReels";
import GitHubSubmission from "./screens/GitHubSubmission";
import XPShop from "./screens/XPShop";
import AdminDashboard from "./screens/AdminDashboard";
import InstructorPanel from "./screens/InstructorPanel";

export type Screen =
  | "login"
  | "student-dashboard"
  | "workspace"
  | "reels"
  | "github"
  | "xp-shop"
  | "admin"
  | "instructor";

export type Role = "student" | "admin" | "instructor";

export default function App() {
  const [screen, setScreen] = useState<Screen>("login");
  const [role, setRole] = useState<Role>("student");

  if (screen === "login") {
    return (
      <LoginScreen
        onLogin={(r) => {
          setRole(r);
          setScreen(r === "admin" ? "admin" : r === "instructor" ? "instructor" : "student-dashboard");
        }}
      />
    );
  }

  const renderScreen = () => {
    switch (screen) {
      case "student-dashboard": return <StudentDashboard onNavigate={setScreen} />;
      case "workspace": return <LearningWorkspace />;
      case "reels": return <TechReels />;
      case "github": return <GitHubSubmission />;
      case "xp-shop": return <XPShop />;
      case "admin": return <AdminDashboard />;
      case "instructor": return <InstructorPanel />;
      default: return <StudentDashboard onNavigate={setScreen} />;
    }
  };

  return (
    <div className="flex h-screen overflow-hidden" style={{ background: "#07090F" }}>
      <Sidebar screen={screen} role={role} onNavigate={setScreen} onLogout={() => setScreen("login")} />
      <main className="flex-1 overflow-y-auto">
        {renderScreen()}
      </main>
    </div>
  );
}
